create
    definer = root@`%` procedure sp_space_analyze_report_while(IN beginDate varchar(512), IN endDate varchar(512),
                                                               IN userId int, IN nickName varchar(512),
                                                               IN statement int)
BEGIN
	#Routine body goes here...
#常量
DECLARE gmt_create_ VARCHAR(512) DEFAULT '';       /**创建空间时间*/     
DECLARE user_name_ VARCHAR(512) DEFAULT '';         /**用户名称*/ 
DECLARE add_living_count_ INT DEFAULT 0;           /**新增小区数量*/ 
DECLARE add_house_count_ INT DEFAULT 0;            /**新增户型数量*/             				
DECLARE locate_space_common_count_ INT DEFAULT 0;  /**空间定位数量*/               
DECLARE locate_house_count_ INT DEFAULT 0;         /**户型定位数量*/ 
DECLARE locate_living_count_ INT DEFAULT 0;        /**空间所属小区数量*/        			             
DECLARE work_content_ VARCHAR(512) DEFAULT '';     /**具体工作内容*/
DECLARE gmt_create_string_ VARCHAR(512) DEFAULT ''; /**创建空间时间*/
DECLARE gmt_date_start_ VARCHAR(512) DEFAULT '';        #用作周的时间显示						/**新增场景文件数（中模）*/
DECLARE user_id INT DEFAULT 0;
DECLARE nick_name VARCHAR(512) DEFAULT ''; 
#DECLARE gmt_create_ varchar(512) DEFAULT '';  
SET user_id=userId;
SET nick_name = nickName;

#查询单位时间内某人新增的小区数量 
SELECT COUNT(id) INTO add_living_count_ FROM base_living  WHERE is_deleted  = 0 AND gmt_create BETWEEN beginDate AND endDate AND creator  = nick_name;
#查询单位时间内某人新增的户型数量
SELECT COUNT(*) INTO add_house_count_ FROM base_house WHERE is_deleted  = 0 AND gmt_create BETWEEN beginDate AND endDate AND creator  = nick_name;
# 空间定位数量
SELECT COUNT(*) INTO locate_space_common_count_ FROM house_space WHERE is_deleted  = 0 AND gmt_create BETWEEN beginDate AND endDate AND creator  = nick_name;
#户型定位数量
SELECT COUNT(*) INTO locate_house_count_ FROM house_space WHERE is_deleted  = 0 AND gmt_create BETWEEN beginDate AND endDate AND creator  = nick_name;
#空间所属小区数量
SELECT COUNT(DISTINCT(h.living_id)) INTO locate_living_count_ FROM base_house h,house_space s WHERE s.house_id = h.id AND h.is_deleted=0 AND s.gmt_create BETWEEN beginDate AND endDate AND s.creator  = nick_name;


/**统计时间*/
	SET gmt_create_=NOW();
/**插入时间*/
  #set gmt_create_=date_format(now(),'%Y-%m-%d %h:%i:%s');
	SELECT SUBSTRING_INDEX(beginDate,' ',1) INTO gmt_create_string_;
	IF statement=2 THEN
	SELECT SUBSTRING_INDEX(beginDate,' ',1) INTO  gmt_date_start_;
	SELECT SUBSTRING_INDEX(endDate,' ',1) INTO gmt_create_string_;
	END IF;
	IF statement=3 THEN
	SELECT SUBSTRING_INDEX(endDate,'-',2) INTO gmt_create_string_;
	END IF;

######################
/**统计时间*/
	#set gmt_statistical_=now();
#########################

#插入数据库
#select space_amount_total_,space_standard_total_,house_type_,templet_amount_total_,space_amount_,space_amount_standard_,templet_putaway_,templet_testing_,templet_not_putaway_,scenes_low_,scenes_middle_,complete_percent_,gmt_create_;
IF statement =1 THEN
	INSERT INTO rpt_space_analyze_day
		(user_id,add_living_count,add_house_count,locate_space_common_count,locate_house_count,locate_living_count,work_content,gmt_date_str,gmt_create)
	VALUES
		(userId,add_living_count_,add_house_count_,locate_space_common_count_,locate_house_count_,locate_living_count_,"",gmt_create_string_,gmt_create_);
END IF;
IF statement =2 THEN
	INSERT INTO rpt_space_analyze_weeks
		(space_total_num,space_standard_total_num,house_type,templet_total_num,space_num,space_standard_num,templet_putaway_num,templet_testing_num,templet_not_putaway_num,scenes_low_num,scenes_middle_num,complete_rate,gmt_create,gmt_create_string,gmt_statistical,templet_putaway_toltal,gmt_date_start)
	VALUES
		(space_total_num_,space_standard_total_num_,house_type_,templet_total_num_,space_num_,space_standard_num_,templet_putaway_num_,templet_testing_num_,templet_not_putaway_num_,scenes_low_num_,scenes_middle_num_,complete_rate_,endDate,gmt_create_string_,gmt_statistical_,templet_putaway_toltal_,gmt_date_start_);
END IF;
IF statement =3 THEN
	INSERT INTO rpt_space_analyze_month
		(space_total_num,space_standard_total_num,house_type,templet_total_num,space_num,space_standard_num,templet_putaway_num,templet_testing_num,templet_not_putaway_num,scenes_low_num,scenes_middle_num,complete_rate,gmt_create,gmt_create_string,gmt_statistical,templet_putaway_toltal)
	VALUES
		(space_total_num_,space_standard_total_num_,house_type_,templet_total_num_,space_num_,space_standard_num_,templet_putaway_num_,templet_testing_num_,templet_not_putaway_num_,scenes_low_num_,scenes_middle_num_,complete_rate_,endDate,gmt_create_string_,gmt_statistical_,templet_putaway_toltal_);
END IF;
END;

