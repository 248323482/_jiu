create
    definer = root@`%` procedure sp_base_product(IN beginDate varchar(512), IN endDate varchar(512), IN dateType int)
begin


		DECLARE i  INT DEFAULT 0; 	/**需要循环的次数*/
		DECLARE values_ varchar(512);	/**游标的value*/
		DECLARE beginString varchar(512);		/**截取时间 年月日 */
		DECLARE endString varchar(512);		/**截取时间 年月日 */
		DECLARE today_number  varchar(512); /**今日数量*/
		DECLARE weeks_number  varchar(512); /**今周数量*/
		DECLARE month_number  varchar(512); /**今月数量*/

		/**汇总插入常量*/
		DECLARE putaway_product_gross_ INT DEFAULT 0; 			/**上架产品总量*/

		DECLARE putaway_product_num_ INT DEFAULT 0;    			/**上架产品数量*/
		DECLARE putaway_middle_model_num_ INT DEFAULT 0;  	/**上架中模数量*/
		DECLARE putaway_low_model_num_ INT DEFAULT 0;    		/**上架低模数量*/
	 
		DECLARE test_product_num_ INT DEFAULT 0;    				/**测试产品数量*/
		DECLARE test_middle_model_num_ INT DEFAULT 0;    		/**测试中模数量*/
		DECLARE test_low_model_num_ INT DEFAULT 0;    			/**测试低模数量*/

		DECLARE out_product_num_ INT DEFAULT 0;   			 		/**未上架产品数量*/
		DECLARE out_middle_model_num_ INT DEFAULT 0;    		/**未上架中模数量*/
		DECLARE out_low_model_num_ INT DEFAULT 0;    	 			/**未上架低模数量*/
		DECLARE gmt_create_string_ varchar(512) DEFAULT ''; /**创建产品时间*/
		DECLARE gmt_statistical_ varchar(512) DEFAULT '';		/**统计时间，系统执行动作时间*/

		DECLARE complete_rate_ varchar(512) DEFAULT '';			/**完成率*/
		DECLARE count  INT DEFAULT 0; 											/**所有产品总数*/
		DECLARE putaway_count  INT DEFAULT 0;							  /**所有上架产品总数*/
		DECLARE gmt_date_start_ varchar(512) DEFAULT '';        #用作周的时间显示
		
		DECLARE _Cur CURSOR FOR  select value  from sys_dictionary where type='productType';/**定义一个游标*/

 



		/**截取时间 年月日 用作查询 产品日报表*/
		select substring_index(beginDate,' ',1) into beginString;
		select substring_index(endDate,' ',1) into endString;
		if dateType=3 then
			select substring_index(endDate,'-',2) into endString;
		end if;

		/*如果已经有了今日数据，则删除后再添加*/
		/**dateType  1 日   2周  3月*/
		if dateType=1 then
				select count(*) into today_number from rpt_product_day where gmt_create_string=beginString;
				if today_number>0 THEN
					delete from  rpt_product_day   where gmt_create_string=beginString;
				end if;
		end if;
		if dateType=2 then
				select count(*) into weeks_number from rpt_product_weeks  where gmt_create_string=endString;
				if weeks_number>0 THEN
					delete from  rpt_product_weeks  where gmt_create_string=endString;
				end if;
		end if;

		if dateType=3 then
				select count(*) into month_number from rpt_product_month where gmt_create_string=endString;
				if month_number>0 THEN
					delete from  rpt_product_month   where gmt_create_string=endString;
				end if;
		end if;


		select count(*) into i from sys_dictionary where type='productType';

		/*******开启游标，循环插入******/
		OPEN _Cur; 
		while i>0  do
			FETCH _Cur INTO values_;  
					CALL  sp_base_product_while(beginDate,endDate,values_,dateType);
				set i = i-1;
				end while;
		close _Cur; 
		/***********关闭游标************/
BEGIN
	DECLARE rpt_product_table varchar(512) DEFAULT '';        #表名
	DECLARE rpt_product_s varchar(512) DEFAULT '';  
	/**************汇总插入*************/
			/**所有上架产品总量*/
			select count(*) into  putaway_product_gross_  from base_product where putaway_state = 1   and is_deleted = 0 and product_code not like 'baimo_%';

			/***今日上架产品数量**/
			select count(*) into putaway_product_num_ from base_product where putaway_state = 1  and is_deleted = 0 and  putaway_modified between beginDate  and endDate  and product_code not like 'baimo_%';
			/***今日上架中模数量**/
			select count(*) into putaway_middle_model_num_ from res_model where   is_deleted = 0 and gmt_create  between beginDate  and endDate and id in(select model_id from base_product where putaway_state = 1 and is_deleted = 0  )  ;
		 /***今日上架低模数量**/
			select count(*) into  putaway_low_model_num_ from res_model where  is_deleted = 0 and  gmt_create  between beginDate  and endDate and id in(select windows_u3dmodel_id from base_product where putaway_state = 1 and is_deleted = 0   ) ;

			/***今日测试中产品数量**/
			select count(*) into test_product_num_ from base_product where putaway_state = 2   and is_deleted = 0 and  test_modified between beginDate  and endDate  and product_code not like 'baimo_%';
			/***今日测试中模数量**/
			select count(*) into  test_middle_model_num_ from res_model where   is_deleted = 0 and gmt_create  between beginDate  and endDate and id in(select model_id from base_product where putaway_state = 2 and is_deleted = 0   ) ;
		 /***今日测试低模数量**/
			select count(*) into  test_low_model_num_ from res_model where  is_deleted = 0 and  gmt_create  between beginDate  and endDate and id in(select windows_u3dmodel_id from base_product where putaway_state = 2 and is_deleted = 0  ) ;

			/***今日未上架产品数量**/
			select count(*) into out_product_num_ from base_product where putaway_state = 0   and is_deleted = 0 and  gmt_create between beginDate  and endDate  and product_code not like 'baimo_%';
			/***今日未上架中模数量**/
			select count(*) into  out_middle_model_num_ from res_model where is_deleted = 0 and   gmt_create  between beginDate  and endDate and id in(select model_id from base_product where putaway_state = 0 and is_deleted = 0 ) ;
		 /***今日未上架低模数量**/
			select count(*) into  out_low_model_num_ from res_model where  is_deleted = 0 and gmt_create  between beginDate  and endDate and id in(select windows_u3dmodel_id from base_product where putaway_state = 0 and is_deleted = 0 ) ;

			/**统计时间*/
		set gmt_statistical_=now();
		/**插入时间*/
		#set gmt_create_=date_format(now(),'%Y-%m-%d');
		select substring_index(beginDate,' ',1) into gmt_create_string_;

		if dateType=2 then
		select SUBSTRING_INDEX(beginDate,' ',1) into  gmt_date_start_;
		select substring_index(endDate,' ',1) into gmt_create_string_;
		end if;

		if dateType=3 then
		select substring_index(endDate,'-',2) into gmt_create_string_;
		end if;

			/**完成率*/
		select count(*) into count from  base_product  where  is_deleted =0  ;
		select count(*) into putaway_count from  base_product  where  is_deleted =0 and    putaway_state = 1;
			
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_count/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;

		/**插入**/
		if dateType = 1 then
			INSERT INTO  rpt_product_day 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'99999999','99999999',beginDate);
		end if;

		if dateType = 2 then 
			INSERT INTO  rpt_product_weeks 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical,gmt_date_start) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'99999999','99999999',endDate,gmt_statistical_,gmt_date_start_);
		end if;


		if dateType = 3 then 
			INSERT INTO  rpt_product_month 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'99999999','99999999',endDate,gmt_statistical_);
		end if;
	/**************汇总插入*************/
#软硬装汇总
	#查询
	if dateType = 1 then
			SELECT SUM(putaway_product_gross) into putaway_product_gross_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_product_num) into putaway_product_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_middle_model_num) into putaway_middle_model_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_low_model_num) into putaway_low_model_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_product_num) into test_product_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_middle_model_num) into test_middle_model_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_low_model_num) into test_low_model_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_product_num) into out_product_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_middle_model_num) into out_middle_model_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_low_model_num) into out_low_model_num_ from rpt_product_day where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_product_gross_/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;
			INSERT INTO  rpt_product_day 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'88888888','88888888',beginDate);
		end if;

		if dateType = 2 then 
			SELECT SUM(putaway_product_gross) into putaway_product_gross_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_product_num) into putaway_product_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_middle_model_num) into putaway_middle_model_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_low_model_num) into putaway_low_model_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_product_num) into test_product_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_middle_model_num) into test_middle_model_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_low_model_num) into test_low_model_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_product_num) into out_product_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_middle_model_num) into out_middle_model_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_low_model_num) into out_low_model_num_ from rpt_product_weeks where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_product_gross_/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;
			INSERT INTO  rpt_product_weeks 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical,gmt_date_start) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'88888888','88888888',endDate,gmt_statistical_,gmt_date_start_);
		end if;


		if dateType = 3 then 
			SELECT SUM(putaway_product_gross) into putaway_product_gross_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_product_num) into putaway_product_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_middle_model_num) into putaway_middle_model_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_low_model_num) into putaway_low_model_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_product_num) into test_product_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_middle_model_num) into test_middle_model_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_low_model_num) into test_low_model_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_product_num) into out_product_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_middle_model_num) into out_middle_model_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_low_model_num) into out_low_model_num_ from rpt_product_month where product_soft_hard_type =1 and gmt_create_string=gmt_create_string_;
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_product_gross_/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;
			INSERT INTO  rpt_product_month 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'88888888','88888888',endDate,gmt_statistical_);
		end if;



if dateType = 1 then
			SELECT SUM(putaway_product_gross) into putaway_product_gross_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_product_num) into putaway_product_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_middle_model_num) into putaway_middle_model_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_low_model_num) into putaway_low_model_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_product_num) into test_product_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_middle_model_num) into test_middle_model_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_low_model_num) into test_low_model_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_product_num) into out_product_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_middle_model_num) into out_middle_model_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_low_model_num) into out_low_model_num_ from rpt_product_day where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_product_gross_/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;
			INSERT INTO  rpt_product_day 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'77777777','77777777',beginDate);
		end if;

		if dateType = 2 then 
			SELECT SUM(putaway_product_gross) into putaway_product_gross_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_product_num) into putaway_product_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_middle_model_num) into putaway_middle_model_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_low_model_num) into putaway_low_model_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_product_num) into test_product_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_middle_model_num) into test_middle_model_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_low_model_num) into test_low_model_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_product_num) into out_product_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_middle_model_num) into out_middle_model_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_low_model_num) into out_low_model_num_ from rpt_product_weeks where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_product_gross_/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;
			INSERT INTO  rpt_product_weeks 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical,gmt_date_start) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'77777777','77777777',endDate,gmt_statistical_,gmt_date_start_);
		end if;


		if dateType = 3 then 
			SELECT SUM(putaway_product_gross) into putaway_product_gross_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_product_num) into putaway_product_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_middle_model_num) into putaway_middle_model_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(putaway_low_model_num) into putaway_low_model_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_product_num) into test_product_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_middle_model_num) into test_middle_model_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(test_low_model_num) into test_low_model_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_product_num) into out_product_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_middle_model_num) into out_middle_model_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			SELECT SUM(out_low_model_num) into out_low_model_num_ from rpt_product_month where product_soft_hard_type =2 and gmt_create_string=gmt_create_string_;
			if count>0 THEN
				if putaway_count>0 THEN
					set complete_rate_ =putaway_product_gross_/count; 
				end if;
				if putaway_count<=0 THEN
					set complete_rate_ =0; 
				end if;
			end if;
			INSERT INTO  rpt_product_month 
			(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
			out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical) 
			values 
			(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
			out_low_model_num_,gmt_create_string_,complete_rate_,'77777777','77777777',endDate,gmt_statistical_);
		end if;

end;
end;

