create
    definer = root@`%` procedure sp_space_analyze_report(IN beginDate varchar(512), IN endDate varchar(512), IN dateType int)
BEGIN
DECLARE i  INT DEFAULT 0;#循环次数
DECLARE userId_ INT DEFAULT 0;  /**游标的userId*/
DECLARE nickName_ VARCHAR(512);
DECLARE beginString VARCHAR(512);		/**截取时间 年月日 */
DECLARE endString VARCHAR(512);		/**截取时间 年月日 */
DECLARE houseType  INT DEFAULT 0;
DECLARE num_today  INT DEFAULT 0;#当日数量
DECLARE num_weeks  INT DEFAULT 0;#当周数量
DECLARE num_month  INT DEFAULT 0;#当月数量

DECLARE gmt_create VARCHAR(512) DEFAULT '';       /**创建空间时间*/     
DECLARE userName VARCHAR(512) DEFAULT '';         /**用户名称*/ 
DECLARE add_living_count INT DEFAULT 0;           /**新增小区数量*/ 
DECLARE add_house_count INT DEFAULT 0;            /**新增户型数量*/             				
DECLARE locate_space_common_count INT DEFAULT 0;  /**空间定位数量*/               
DECLARE locate_house_count INT DEFAULT 0;         /**户型定位数量*/ 
DECLARE locate_living_count INT DEFAULT 0;        /**空间所属小区数量*/        			             
DECLARE work_Content VARCHAR(512) DEFAULT '';     /**具体工作内容*/
DECLARE gmt_create_string_ VARCHAR(512) DEFAULT ''; /**创建空间时间*/
DECLARE gmt_statistical_ VARCHAR(512) DEFAULT '';		/**统计时间，系统执行动作时间*/
DECLARE gmt_date_start_ VARCHAR(512) DEFAULT '';        #用作周的时间显示

DECLARE _Cur CURSOR FOR  SELECT u.id,u.nick_name FROM sys_user u LEFT JOIN sys_group g ON u.group_id = g.id  WHERE g.id = 36 AND u.is_deleted = 0;/**定义一个游标查询设计组的所有人员*/
/**截取时间 年月日 用作查询 */
SELECT SUBSTRING_INDEX(beginDate,' ',1) INTO beginString;
IF dateType=2 THEN#周
		SELECT SUBSTRING_INDEX(beginDate,' ',1) INTO  gmt_date_start_;
			SELECT SUBSTRING_INDEX(endDate,' ',1) INTO endString;
END IF;

