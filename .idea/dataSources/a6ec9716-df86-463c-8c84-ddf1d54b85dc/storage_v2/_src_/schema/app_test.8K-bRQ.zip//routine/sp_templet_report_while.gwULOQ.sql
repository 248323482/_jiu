create
    definer = root@`%` procedure sp_templet_report_while(IN beginDate varchar(512), IN endDate varchar(512),
                                                         IN houseType int, IN statement int)
BEGIN
	#Routine body goes here...
#常量
DECLARE house_type_ INT DEFAULT 0;									/**空间类型*/
DECLARE space_total_num_ INT DEFAULT 0;							/**空间总数量*/
DECLARE space_standard_total_num_ INT DEFAULT 0;		/**标准空间总数量*/
DECLARE space_num_ INT DEFAULT 0;										/**新增空间数*/
DECLARE space_standard_num_ INT DEFAULT 0;					/**新增标准空间数*/

DECLARE templet_total_num_ INT DEFAULT 0;						/**样板房总数量*/
DECLARE templet_putaway_toltal_ INT DEFAULT 0;			/**已上架样板房总数量*/
DECLARE templet_putaway_num_ INT DEFAULT 0;					/**新增样板房数（已上架）*/
DECLARE templet_testing_num_ INT DEFAULT 0;					/**新增样板房数（测试中）*/
DECLARE templet_not_putaway_num_ INT DEFAULT 0;			/**新增样板房数（未上架）*/

DECLARE scenes_low_num_ INT DEFAULT 0;							/**新增场景文件数（低模）*/
DECLARE scenes_middle_num_ INT DEFAULT 0;						/**新增场景文件数（中模）*/

DECLARE complete_rate_ varchar(512) DEFAULT '';			/**样板房完成率*/
DECLARE gmt_create_string_ varchar(512) DEFAULT ''; /**创建空间时间*/
DECLARE gmt_statistical_ varchar(512) DEFAULT '';		/**统计时间，系统执行动作时间*/
DECLARE gmt_date_start_ varchar(512) DEFAULT '';        #用作周的时间显示
#DECLARE gmt_create_ varchar(512) DEFAULT '';  
SET house_type_=houseType;

#已上架样板房总数
SELECT COUNT(id) into templet_putaway_toltal_ from design_templet where putaway_state=1 and is_deleted=0;
#空间总数量
select COUNT(*) into space_total_num_ from space_common WHERE is_deleted=0 AND space_function_id=houseType; 
#标准空间总数量
select COUNT(*) into space_standard_total_num_ from space_common WHERE is_deleted=0 AND is_standard_space=1 AND space_function_id=houseType;
#样板房总数
select COUNT(*) into templet_total_num_ from design_templet dt,space_common sc WHERE dt.space_common_id=sc.id AND dt.is_deleted=0 AND sc.space_function_id=houseType;
#日新增空间数
select COUNT(*) into space_num_ from space_common WHERE is_deleted=0 AND space_function_id=houseType AND gmt_create BETWEEN beginDate AND endDate;
#日新增标准空间数
select COUNT(*) into space_standard_num_ from space_common WHERE is_deleted=0 AND space_function_id=houseType and is_standard_space=1 AND gmt_create BETWEEN beginDate AND endDate;
#日新增样板房数（已上架）
select COUNT(*) into templet_putaway_num_ from design_templet dt,space_common sco WHERE dt.space_common_id=sco.id AND dt.is_deleted=0 AND sco.space_function_id=houseType and dt.putaway_state=1 and dt.gmt_first_putaway BETWEEN beginDate AND endDate;
#日新增样板房数（测试中）
select COUNT(*) into templet_testing_num_ from design_templet dt,space_common sco WHERE dt.space_common_id=sco.id AND dt.is_deleted=0 AND sco.space_function_id=houseType and dt.putaway_state=2 and dt.gmt_create BETWEEN beginDate AND endDate;
#日新增样板房数（未上架）
select COUNT(*) into templet_not_putaway_num_ from design_templet dt,space_common sco WHERE dt.space_common_id=sco.id AND dt.is_deleted=0 AND sco.space_function_id=houseType and dt.putaway_state=0 and dt.gmt_create BETWEEN beginDate AND endDate;
#日新增场景文件数（低模）
SELECT COUNT(*) into scenes_low_num_ from res_model res, design_templet dt where dt.gmt_create BETWEEN beginDate AND endDate and dt.pc_model_u3d_id=res.id and dt.space_common_id in(SELECT id from space_common WHERE space_function_id=houseType);
#日新增场景文件数（中模）
SELECT COUNT(*) into scenes_middle_num_ from res_model res,space_common sco where sco.gmt_create BETWEEN beginDate AND endDate and sco.model_3d_id=res.id and sco.space_function_id=houseType;
/**完成率*/
		if  templet_putaway_num_<=0 THEN
			set complete_rate_ =0; 
		end if;
		if  templet_putaway_num_>0 THEN
			set complete_rate_ =templet_putaway_num_/templet_total_num_;
		end if;

/**统计时间*/
	set gmt_statistical_=now();
/**插入时间*/
  #set gmt_create_=date_format(now(),'%Y-%m-%d %h:%i:%s');
	select substring_index(beginDate,' ',1) into gmt_create_string_;
	if statement=2 then
	select SUBSTRING_INDEX(beginDate,' ',1) into  gmt_date_start_;
	select substring_index(endDate,' ',1) into gmt_create_string_;
	end if;
	if statement=3 then
	select substring_index(endDate,'-',2) into gmt_create_string_;
	end if;

######################
/**统计时间*/
	#set gmt_statistical_=now();
#########################

#插入数据库
#select space_amount_total_,space_standard_total_,house_type_,templet_amount_total_,space_amount_,space_amount_standard_,templet_putaway_,templet_testing_,templet_not_putaway_,scenes_low_,scenes_middle_,complete_percent_,gmt_create_;
if statement =1 then
	INSERT into rpt_templet_day
		(space_total_num,space_standard_total_num,house_type,templet_total_num,space_num,space_standard_num,templet_putaway_num,templet_testing_num,templet_not_putaway_num,scenes_low_num,scenes_middle_num,complete_rate,gmt_create,gmt_create_string,gmt_statistical,templet_putaway_toltal)
	VALUES
		(space_total_num_,space_standard_total_num_,house_type_,templet_total_num_,space_num_,space_standard_num_,templet_putaway_num_,templet_testing_num_,templet_not_putaway_num_,scenes_low_num_,scenes_middle_num_,complete_rate_,beginDate,gmt_create_string_,gmt_statistical_,templet_putaway_toltal_);
end if;
if statement =2 then
	INSERT into rpt_templet_weeks
		(space_total_num,space_standard_total_num,house_type,templet_total_num,space_num,space_standard_num,templet_putaway_num,templet_testing_num,templet_not_putaway_num,scenes_low_num,scenes_middle_num,complete_rate,gmt_create,gmt_create_string,gmt_statistical,templet_putaway_toltal,gmt_date_start)
	VALUES
		(space_total_num_,space_standard_total_num_,house_type_,templet_total_num_,space_num_,space_standard_num_,templet_putaway_num_,templet_testing_num_,templet_not_putaway_num_,scenes_low_num_,scenes_middle_num_,complete_rate_,endDate,gmt_create_string_,gmt_statistical_,templet_putaway_toltal_,gmt_date_start_);
end if;
if statement =3 then
	INSERT into rpt_templet_month
		(space_total_num,space_standard_total_num,house_type,templet_total_num,space_num,space_standard_num,templet_putaway_num,templet_testing_num,templet_not_putaway_num,scenes_low_num,scenes_middle_num,complete_rate,gmt_create,gmt_create_string,gmt_statistical,templet_putaway_toltal)
	VALUES
		(space_total_num_,space_standard_total_num_,house_type_,templet_total_num_,space_num_,space_standard_num_,templet_putaway_num_,templet_testing_num_,templet_not_putaway_num_,scenes_low_num_,scenes_middle_num_,complete_rate_,endDate,gmt_create_string_,gmt_statistical_,templet_putaway_toltal_);
end if;
END;

