create
    definer = root@`%` procedure sp_base_product_run()
begin

	#逻辑是，直接调用这个存储过程，取当前系统时间，日报取昨天时间范围的数据；
	#周报来说，如果是周一到周日，
	#取当前一周时间范围内的数据，如果是周一的跑上一周的数据范围一次，
	#如果是月报，每天的参数是本月第一天到最后一天，当前时间是1号的，跑上月的全部数据。

	DECLARE day_begin varchar(512);     #昨天开始时间
	DECLARE day_end varchar(512);				#昨天结束时间

	DECLARE weeks_last_begin varchar(512);  	#上周开始时间
	DECLARE weeks_last_end varchar(512);			#上周结束时间	

	DECLARE month_last_begin varchar(512);  	#上个月的第1天
	DECLARE month_last_end varchar(512);			#上个月的最后1天

	DECLARE weeks_begin varchar(512);  	#本周开始时间
	DECLARE weeks_end varchar(512);			#本周结束时间	

	DECLARE month_begin varchar(512);  	#本个月的第1天
	DECLARE month_end varchar(512);			#本个月的最后1天


	DECLARE currentTime  varchar(512);  #系统当前时间
	DECLARE weeks_one  varchar(512);		#本周一号
	DECLARE month_one  varchar(512);		#本月一号
 

	set day_begin = CONCAT(date_format(adddate(now(),-1),'%Y-%m-%d')," 00:00:00"); 																																				#获得昨天开始时间
	set day_end = CONCAT(date_format(adddate(now(),-1),'%Y-%m-%d')," 23:59:59"); 																																					#获得昨天结束时间
 
  set weeks_last_begin = CONCAT(date_sub(subdate(curdate(),date_format(curdate(),'%w')-1),interval 1 week)," 00:00:00");        												#获得上周开始时间
	set weeks_last_end =   CONCAT(date_sub(subdate(curdate(),date_format(curdate(),'%w')-7),interval 1 week)," 23:59:59"); 			 													#获得上周结束时间	

  set month_last_begin = CONCAT(date_sub(date_sub(date_format(now(),'%y-%m-%d'),interval extract(day from now())-1 day),interval 1 month)," 00:00:00"); #获得上个月的第1天
	set month_last_end =   CONCAT(date_sub(date_sub(date_format(now(),'%y-%m-%d'),interval extract(day from now()) day),interval 0 month)," 23:59:59"); 	#获得上个月的最后1天
 

  set weeks_begin = CONCAT(subdate(curdate(),date_format(curdate(),'%w')-1)," 00:00:00");       																												#获得本周开始时间
	set weeks_end =   CONCAT(subdate(curdate(),date_format(curdate(),'%w')-7)," 23:59:59"); 			 																												#获得本周结束时间	

  set month_begin = CONCAT(date_sub(date_format(now(),'%y-%m-%d'),interval extract(day from now())-1 day)," 00:00:00"); 																#获得本月的第1天
	set month_end =   CONCAT(date_sub( date_sub(date_format(now(),'%y-%m-%d'),interval extract(day from now()) day),interval -1 month)," 23:59:59"); 			#获得本月的最后1天

	set currentTime = date_format(now(),'%Y-%m-%d');    																																																	#获取系统当前时间
  set weeks_one =  subdate(curdate(),date_format(curdate(),'%w')-1); 																																										#获得本周一号
  set month_one = date_sub(date_sub(date_format(now(),'%y-%m-%d'),interval extract(day from now())-1 day),interval 0 month) ;  													#获得本月一号

	#执行日报表
  call sp_base_product(day_begin,day_end,'1');


	#执行周报表
	if currentTime = weeks_one THEN 						#如果今天是周一，执行上周报表
		call sp_base_product(weeks_last_begin,weeks_last_end,'2');
 
	end if;
	if currentTime != weeks_one THEN 						#如果今天不是周一，执行本周报表
		call sp_base_product(weeks_begin,weeks_end,'2');
 
	end if;

	#执行月报表
	if currentTime = month_one THEN 						#如果今天是月一号，执行上月报表
		call sp_base_product(month_last_begin,month_last_end,'3');
 
	end if;
	if currentTime != month_one THEN 						#如果今天不是月一号，执行本月报表
		call sp_base_product(month_begin,month_end,'3');
 
	end if;


  select  day_begin;
 select day_end;
 select  weeks_last_begin;
 select weeks_last_end;
 select  month_last_begin;
 select month_last_end;
 select  weeks_begin;
 select weeks_end;
 select  month_begin;
 select month_end;   

 /*select currentTime;
 select  weeks_one;
 select month_one;*/
 
end;

