create
    definer = root@`%` procedure sp_base_product_while(IN beginDate varchar(512), IN endDate varchar(512),
                                                       IN productType int, IN statement int)
begin

  /******常量定义******/
  DECLARE product_soft_hard_type_ INT DEFAULT 0; 			/**软硬装类型 1软 2硬*/
  DECLARE product_type_ INT DEFAULT 0; 								/**产品类型*/

  DECLARE putaway_product_gross_ INT DEFAULT 0; 			/**上架产品总量*/

	DECLARE putaway_product_num_ INT DEFAULT 0;    			/**上架产品数量*/
  DECLARE putaway_middle_model_num_ INT DEFAULT 0;  	/**上架中模数量*/
  DECLARE putaway_low_model_num_ INT DEFAULT 0;    		/**上架低模数量*/
 
  DECLARE test_product_num_ INT DEFAULT 0;    				/**测试产品数量*/
  DECLARE test_middle_model_num_ INT DEFAULT 0;    		/**测试中模数量*/
  DECLARE test_low_model_num_ INT DEFAULT 0;    			/**测试低模数量*/

  DECLARE out_product_num_ INT DEFAULT 0;   			 		/**未上架产品数量*/
  DECLARE out_middle_model_num_ INT DEFAULT 0;    		/**未上架中模数量*/
  DECLARE out_low_model_num_ INT DEFAULT 0;    	 			/**未上架低模数量*/
 
	DECLARE gmt_create_string_ varchar(512) DEFAULT ''; /**创建产品时间*/
	DECLARE gmt_statistical_ varchar(512) DEFAULT '';		/**统计时间，系统执行动作时间*/
	DECLARE complete_rate_ varchar(512) DEFAULT '';			/**完成率*/

	DECLARE count  INT DEFAULT 0; 											/**所有产品总数*/
	DECLARE putaway_count  INT DEFAULT 0;							  /**所有上架产品总数*/
	DECLARE gmt_date_start_ varchar(512) DEFAULT '';        #用作周的时间显示
	#查软硬装类型
	#SELECT productType;
	#select sd.value into product_soft_hard_type_ from sys_dictionary sd where sd.type='totalType' and sd.is_deleted=0 and sd.value=productType;
  /**软硬装类型 2软 1硬*/
	#set product_soft_hard_type_ = softHardType;
	#SELECT product_soft_hard_type_;

 /**软硬装类型 2软 1硬*/
	set product_soft_hard_type_=2;
	if productType=1 THEN
		set product_soft_hard_type_=1;
	end if;
	if productType=2 THEN
		set product_soft_hard_type_=1;
	end if;
	if productType=3 THEN
		set product_soft_hard_type_=1;
	end if;
	if productType=4 THEN
		set product_soft_hard_type_=1;
	end if;
	if productType=25 THEN
		set product_soft_hard_type_=1;
	end if;

	/**所有上架产品总量*/
	select count(*) into  putaway_product_gross_  from base_product where putaway_state = 1  and product_type_value=productType and is_deleted = 0 and product_code not like 'baimo_%';
	/***今日上架产品数量**/
	select count(*) into putaway_product_num_ from base_product where putaway_state = 1 and product_type_value=productType and is_deleted = 0 and  putaway_modified between beginDate  and endDate  and product_code not like 'baimo_%';
	/***今日上架中模数量**/
  select count(*) into putaway_middle_model_num_ from res_model where  is_deleted = 0 and   gmt_create  between beginDate  and endDate and id in(select model_id from base_product where putaway_state = 1 and is_deleted = 0   and product_type_value=productType) ;
 /***今日上架低模数量**/
  select count(*) into  putaway_low_model_num_ from res_model where  is_deleted = 0 and   gmt_create  between beginDate  and endDate and id in(select windows_u3dmodel_id from base_product where putaway_state = 1 and is_deleted = 0   and product_type_value=productType) ;

  /***今日测试中产品数量**/
	select count(*) into test_product_num_ from base_product where putaway_state = 2  and product_type_value=productType and is_deleted = 0 and  test_modified between beginDate  and endDate and product_code not like 'baimo_%'; 
	/***今日测试中模数量**/
  select count(*) into  test_middle_model_num_ from res_model where  is_deleted = 0 and   gmt_create  between beginDate  and endDate and id in(select model_id from base_product where putaway_state = 2 and is_deleted = 0   and product_type_value=productType) ;
 /***今日测试低模数量**/
  select count(*) into  test_low_model_num_ from res_model where is_deleted = 0 and    gmt_create  between beginDate  and endDate and id in(select windows_u3dmodel_id from base_product where putaway_state = 2 and is_deleted = 0  and product_type_value=productType) ;

	/***今日未上架产品数量**/
	select count(*) into out_product_num_ from base_product where putaway_state = 0  and product_type_value=productType and is_deleted = 0 and  gmt_create between beginDate  and endDate  and product_code not like 'baimo_%'; 
	/***今日未上架中模数量**/
  select count(*) into  out_middle_model_num_ from res_model where   is_deleted = 0 and  gmt_create  between beginDate  and endDate and id in(select model_id from base_product where putaway_state = 0 and is_deleted = 0 and   product_type_value=productType) ;
 /***今日未上架低模数量**/
  select count(*) into  out_low_model_num_ from res_model where  is_deleted = 0 and  gmt_create  between beginDate  and endDate and id in(select windows_u3dmodel_id from base_product where putaway_state = 0 and is_deleted = 0 and  product_type_value=productType) ;

	/**统计时间*/
	set gmt_statistical_=now();
	/**插入时间*/
  #set gmt_create_=date_format(now(),'%Y-%m-%d');
	select substring_index(beginDate,' ',1) into gmt_create_string_;

	if statement=2 then
	select SUBSTRING_INDEX(beginDate,' ',1) into  gmt_date_start_;
	select substring_index(endDate,' ',1) into gmt_create_string_;
	end if;

	if statement=3 then
	select substring_index(endDate,'-',2) into gmt_create_string_;
	end if;


	/**完成率*/
	select count(*) into count from  base_product  where  is_deleted =0 and   product_type_value=productType;
	select count(*) into putaway_count from  base_product  where  is_deleted =0 and   product_type_value=productType and putaway_state = 1;
		
		if count>0 THEN
			if putaway_count>0 THEN
				set complete_rate_ =putaway_count/count; 
			end if;
			if putaway_count<=0 THEN
				set complete_rate_ =0; 
			end if;
		end if;

	/**打印*/
	#select putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_
	#,out_low_model_num_,gmt_create_,complete_rate_;

	/**插入**/
	if statement =1 then
		INSERT INTO  rpt_product_day
		(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
		out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create) 
		values 
		(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
		out_low_model_num_,gmt_create_string_,complete_rate_,productType,product_soft_hard_type_,endDate);
	end if;

	if statement =2 then 
		INSERT INTO  rpt_product_weeks  
		(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
		out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical,gmt_date_start) 
		values 
		(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
		out_low_model_num_,gmt_create_string_,complete_rate_,productType,product_soft_hard_type_,endDate,gmt_statistical_,gmt_date_start_);
	end if;


	if statement =3 then 
		INSERT INTO  rpt_product_month  
		(putaway_product_gross,putaway_product_num,putaway_middle_model_num,putaway_low_model_num,test_product_num,test_middle_model_num,test_low_model_num,out_product_num,out_middle_model_num,
		out_low_model_num,gmt_create_string,complete_rate,product_type,product_soft_hard_type,gmt_create,gmt_statistical) 
		values 
		(putaway_product_gross_,putaway_product_num_,putaway_middle_model_num_,putaway_low_model_num_,test_product_num_,test_middle_model_num_,test_low_model_num_,out_product_num_,out_middle_model_num_,
		out_low_model_num_,gmt_create_string_,complete_rate_,productType,product_soft_hard_type_,endDate,gmt_statistical_);
	end if;

end;

