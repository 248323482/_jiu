create
    definer = root@`%` procedure sp_house_cover(IN expectHouseSumNation int, IN expectHouseSum int,
                                                IN expectCitySum int, IN expectAreaSum int)
BEGIN
#定义常量
DECLARE province_code_ varchar(32) DEFAULT ''; 					#省
DECLARE city_house_num_ int; 														#有户型覆盖的市数量
DECLARE city_cover_rate_ varchar(32) DEFAULT ''; 				#市户型覆盖率
DECLARE expect_house_sum_ int; 													#预估户型完成总数
DECLARE actual_house_sum_ int DEFAULT 0; 								#实际户型完成总数
DECLARE expect_house_rate_ varchar(32) DEFAULT ''; 			#预估户型完成率
########################
DECLARE city_code_ varchar(32); 												#市
DECLARE area_house_num_ int DEFAULT 0; 							#有户型覆盖的区数量
DECLARE area_cover_rate_ varchar(32) DEFAULT ''; 		#区户型覆盖率
DECLARE expect_city_sum_ int DEFAULT 0; 						#预估市户型总数
DECLARE actual_city_sum_ int DEFAULT 0; 						#实际已完成市户型总数
DECLARE city_complet_rate_ varchar(32) DEFAULT ''; 	#市户型完成率
DECLARE j  INT DEFAULT 0;#循环次数
DECLARE city_values varchar(512);	/**游标的value*/
##############################
DECLARE area_code_ varchar(32); 												#区
DECLARE expect_area_sum_ int DEFAULT 0; 						#预估区户型总数
DECLARE actual_area_sum_ int DEFAULT 0; 						#实际已完成区户型总数
DECLARE area_complet_rate_ varchar(32) DEFAULT '';  #区户型完成率
DECLARE gmt_create_ varchar(512) DEFAULT '';					#创建时间
DECLARE k  INT DEFAULT 0;#循环次数
DECLARE area_values varchar(512);	/**游标的value*/
################################
DECLARE pro_num_  INT DEFAULT 0;#全国省的数量（包括直辖市）
DECLARE city_num_  INT DEFAULT 0;#该省中市的总数
DECLARE area_num_  INT DEFAULT 0;#该市中区的总数

DECLARE i  INT DEFAULT 0;#循环次数
DECLARE pro_values varchar(512);	/**游标的value*/

#游标(省列表)
DECLARE Pro CURSOR FOR SELECT area_code from base_area where is_deleted=0 and level_id=1;
#删除表数据
TRUNCATE TABLE rpt_house_cover;
set gmt_create_=now();

#汇总：###########################start
#有户型覆盖的省数量
			SELECT COUNT(ba.id) into city_house_num_ from base_area ba where ba.is_deleted=0 and ba.level_id=1 and ba.pid=0 and area_code in (SELECT substring_index(substring_index(bh.area_long_code,'.',2),'.',-1)  from base_house bh where bh.is_deleted=0);
		  			#省户型覆盖率(有数据的省的数量/全国中省的的总数量)
				#全国省的的总数量
				SELECT COUNT(id) into pro_num_ from base_area where is_deleted=0 and level_id=1 and pid=0;
			
			if city_house_num_ > 0 THEN
				set city_cover_rate_ = FORMAT(FORMAT(city_house_num_ / pro_num_,4)*100,2);
			else
				set city_cover_rate_ = '0.00';
			end if;
			#实际户型完成总数
			SELECT COUNT(bh.id) into actual_house_sum_ from base_house bh where bh.is_deleted=0;
			#预估户型完成总数
			if expectHouseSumNation > 0 THEN
				set expect_house_sum_ = expectHouseSumNation;
			ELSE
				set expect_house_sum_ = actual_house_sum_;
			end if;
			
			#预估户型完成率(实际户型完成总数/预估户型完成总数/)
			if actual_house_sum_ > 0 THEN
				set expect_house_rate_ = FORMAT(FORMAT(actual_house_sum_ / expect_house_sum_,4)*100,2);
			ELSE
				set expect_house_rate_ = '0.00';
			end if;
#插入数据库
INSERT into rpt_house_cover
	(province_code,city_house_num,city_cover_rate,expect_house_sum,actual_house_sum,expect_house_rate,city_code,area_house_num,area_cover_rate,expect_city_sum,actual_city_sum,city_complet_rate,area_code,expect_area_sum,actual_area_sum,area_complet_rate,gmt_create,level_id)
VALUES
	('99999999',city_house_num_,city_cover_rate_,expect_house_sum_,actual_house_sum_,expect_house_rate_,null,null,null,null,null,null,null,null,null,null,gmt_create_,null);
#汇总：###########################end
######################################################################################################
#开启游标
	#省份数量
	SELECT count(id) into i from base_area where is_deleted=0 and level_id=1;
set gmt_create_=now();
OPEN Pro;
	while i>0 DO
		FETCH Pro into pro_values;
#查询
			#省
			set province_code_ = pro_values;
			#有户型覆盖的市数量
		  SELECT COUNT(ba.id) into city_house_num_ from base_area ba where ba.is_deleted=0 and ba.level_id=2 and ba.pid=pro_values and substring_index(ba.long_code,'.',3)  in (SELECT substring_index(bh.area_long_code,'.',3)  from base_house bh where bh.is_deleted=0);
			#市户型覆盖率(有数据的市的数量/该省中市的的总数量)
				#该省中市的的总数量
				SELECT COUNT(id) into city_num_ from base_area where is_deleted=0 and level_id=2 and pid=pro_values;
			
			if city_house_num_ > 0 THEN
				set city_cover_rate_ = FORMAT(FORMAT(city_house_num_ / city_num_,4)*100,2);
			else
				set city_cover_rate_ = '0.00';
			end if;
			#实际户型完成总数
			SELECT COUNT(bh.id) into actual_house_sum_ from base_house bh where bh.is_deleted=0 and substring_index(substring_index(bh.area_long_code ,'.',2),'.',-1) = pro_values;
			#预估户型完成总数
			if expectHouseSum > 0 THEN
				set expect_house_sum_ = expectHouseSum;
			ELSE
				set expect_house_sum_ = actual_house_sum_;
			end if;
			
			#预估户型完成率(实际户型完成总数/预估户型完成总数/)
			if actual_house_sum_ > 0 THEN
				set expect_house_rate_ = FORMAT(FORMAT(actual_house_sum_ / expect_house_sum_,4)*100,2);
			ELSE
				set expect_house_rate_ = '0.00';
			end if;
	##############################################################################		
#该省中市的列表
BEGIN


#游标
DECLARE City CURSOR FOR SELECT area_code from base_area where is_deleted=0 and pid =pro_values;

#该省下市的数量
SELECT COUNT(id) INTO j from base_area where is_deleted=0 and level_id=2 and pid=pro_values;
			OPEN City;
			while j>0 DO
				FETCH City into city_values;
				#市
				set city_code_ = city_values;
				#有户型覆盖的区数量
				SELECT COUNT(ba.id) into area_house_num_ from base_area ba where ba.is_deleted=0 and ba.level_id=3 and ba.pid=city_values and ba.long_code  in (SELECT bh.area_long_code  from base_house bh where bh.is_deleted=0);
				#区户型覆盖率(实际区有数据的数量/市中区总数量)
					#市中区总数量
					SELECT COUNT(id) into area_num_ from base_area where is_deleted=0 and level_id=3 and pid= city_values;
				if area_house_num_ > 0 THEN
						set area_cover_rate_ =FORMAT(FORMAT(area_house_num_ / area_num_,4) * 100,2);
				ELSE
					set area_cover_rate_ = '0.00';
				end if;
				#实际已完成市户型总数
				SELECT COUNT(id) into actual_city_sum_ from base_house bh where bh.is_deleted=0 and substring_index(substring_index(bh.area_long_code ,'.',3),'.',-1) = city_values;
				#预估市户型总数
				if expectHouseSum > 0 then
					set expect_city_sum_ = expectCitySum;
				ELSE
					set expect_city_sum_ = actual_city_sum_;
				end if;
				
				#市户型完成率
				if  actual_city_sum_ > 0 THEN
					set city_complet_rate_ = FORMAT(FORMAT(actual_city_sum_ / expect_city_sum_,4) * 100,2);
				ELSE
					set city_complet_rate_ = '0.00';
				end if;
				
############################################################################
#该市中区的列表
BEGIN

#游标
DECLARE Area CURSOR FOR SELECT area_code from base_area where is_deleted=0 and level_id=3 and pid =city_values;
#该市中区数量
SELECT COUNT(id) into k from base_area where is_deleted=0 and level_id=3 and pid=city_values;

			OPEN Area;
				while k>0 DO
					FETCH Area into area_values;
					set area_code_=area_values;
					#实际已完成区户型总数
					SELECT COUNT(id) into actual_area_sum_ from base_house bh where bh.is_deleted=0 and substring_index(substring_index(bh.area_long_code ,'.',4),'.',-1) = area_values;
					#预估区户型总数
					if expectAreaSum > 0 THEN
						set expect_area_sum_ = expectAreaSum;
					ELSE
						set expect_area_sum_ = actual_area_sum_;
					end if;
					
					#区户型完成率
					IF actual_area_sum_ > 0 THEN
						set area_complet_rate_ = FORMAT(FORMAT(actual_area_sum_ / expect_area_sum_,4) * 100,2);
				
					ELSE
						set area_complet_rate_ = '0.00';
					end if;
					
#插入数据库
SELECT area_name into province_code_  from base_area where is_deleted=0 and level_id=1 and area_code=province_code_;
SELECT area_name into city_code_  from base_area where is_deleted=0 and level_id=2 and area_code=city_code_;
SELECT area_name into area_code_  from base_area where is_deleted=0 and level_id=3 and area_code=area_code_;
INSERT into rpt_house_cover
	(province_code,city_house_num,city_cover_rate,expect_house_sum,actual_house_sum,expect_house_rate,city_code,area_house_num,area_cover_rate,expect_city_sum,actual_city_sum,city_complet_rate,area_code,expect_area_sum,actual_area_sum,area_complet_rate,gmt_create,level_id)
VALUES
	(province_code_,city_house_num_,city_cover_rate_,expect_house_sum_,actual_house_sum_,expect_house_rate_,city_code_,area_house_num_,area_cover_rate_,expect_city_sum_,actual_city_sum_,city_complet_rate_,area_code_,expect_area_sum_,actual_area_sum_,area_complet_rate_,gmt_create_,3);

				 set k = k-1;
				end while;
			CLOSE Area;
END;
				 set j = j-1;
				end while;
			CLOSE City;
END;		
		set i = i-1;
	end while;
CLOSE Pro;
END;

