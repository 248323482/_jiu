create
    definer = root@`%` procedure res_design_file()
begin
 
	 DECLARE file_code_ varchar(512) DEFAULT '';   /*文件编码*/
	 DECLARE file_name_ varchar(512) DEFAULT '';	/*文件名称*/
	 DECLARE file_original_name_ varchar(512) DEFAULT '';   /*文件原名称*/
	 DECLARE file_type_ varchar(512) DEFAULT '';		/* 文件类别 */
	 DECLARE file_size_ varchar(512) DEFAULT '';	/* 文件大小 */
	 DECLARE file_weight_ varchar(512) DEFAULT '';	/*  图片长、模型宽 */
	 DECLARE file_high_ varchar(512) DEFAULT '';	/*  图片高、模型高 */
	 DECLARE file_length_ INT DEFAULT 0; 		/* 长（模型） */
	 DECLARE file_suffix_ varchar(512) DEFAULT '';		/* 文件后缀 */
	 DECLARE file_format_ varchar(512) DEFAULT '';	/* 文件格式（图片） */
	 DECLARE file_level_ varchar(512) DEFAULT '';	/* 文件级别 */
	 DECLARE file_path_ varchar(512) DEFAULT '';	/* 文件路径 */
	 DECLARE file_desc_ varchar(512) DEFAULT '';	/*  文件描述 */
	 DECLARE file_ordering_ INT DEFAULT 0; 	/* 文件排序 */
		/*  */
	 DECLARE sys_code_ varchar(512) DEFAULT '';/* 系统编码 */
	 DECLARE creator_ varchar(512) DEFAULT '';  /* 创建者 */
	 DECLARE gmt_create_ timestamp DEFAULT null; 	/* 创建时间 */
	 DECLARE modifier_ varchar(512) DEFAULT '';  /* 修改人 */
	 DECLARE gmt_modified_ timestamp DEFAULT null; 	/* 修改时间 */
	 DECLARE is_deleted_ INT DEFAULT 0; 	/* 是否删除 */
	 DECLARE file_key_ varchar(512) DEFAULT '';
	 DECLARE business_id_ INT DEFAULT 0;  /* 业务id */
	 DECLARE small_pic_info_ varchar(512) DEFAULT '';  /* 缩略图（图片） */
	 DECLARE view_point_ INT DEFAULT 0; 	/* 观察点（渲染图） */
	 DECLARE scene_ INT DEFAULT 0; 	/* 场景（渲染图） */
	 DECLARE sequence_ INT DEFAULT 0; 	/* 顺序（图片） */
	 DECLARE rendering_type_ INT DEFAULT 0;	/* 渲染类型（渲染图） */
	 DECLARE pano_path_ varchar(512) DEFAULT '';   /* 720度渲染图路径（渲染图） */
	 DECLARE min_height_ INT DEFAULT 0;  /* 最小高度（模型） */
	 DECLARE is_model_share_ INT DEFAULT 0;  /* 是否共享（模型） */
	 
	 DECLARE  att1_ varchar(512) DEFAULT '';
	 DECLARE  att2_ varchar(512) DEFAULT '';
	 DECLARE  att3_ varchar(512) DEFAULT '';
	 DECLARE  att4_ varchar(512) DEFAULT '';
	 DECLARE  att5_ varchar(512) DEFAULT '';
	 DECLARE  att6_ varchar(512) DEFAULT '';

	 DECLARE  numa1_ INT DEFAULT 0;
	 DECLARE  numa2_ INT DEFAULT 0;
	 DECLARE  numa3_ INT DEFAULT 0;
	 DECLARE  numa4_ INT DEFAULT 0;
	 DECLARE  numa5_ INT DEFAULT 0;
	 DECLARE  numa6_ INT DEFAULT 0;

	 DECLARE  remark_ varchar(512) DEFAULT ''; /* 备注 */

	 DECLARE  i INT DEFAULT 0;
   DECLARE  id_value INT DEFAULT 0;
	 DECLARE _Cur CURSOR FOR  select id  from res_file where  is_deleted = 0   and file_key   like  '%designPlan%' ;/**定义一个游标*/
	 SELECT count(*) into i from res_file where is_deleted = 0  and file_key   like  '%designPlan%';
 
 
 select i ;
			/*开启游标，循环*/
			OPEN _Cur; 
			while i>0  do
				FETCH _Cur INTO id_value;  
							select 
							file_code,file_name,file_original_name,file_type,file_size,file_suffix,
							file_level,file_path,file_desc,file_ordering,sys_code,creator,gmt_create,modifier,gmt_modified,is_deleted,file_key,business_id
							,att4,att5,att6,num_att2,num_att3,num_att4,remark
							into 
							file_code_,file_name_,file_original_name_,file_type_,file_size_,file_suffix_,
							file_level_,file_path_,file_desc_,file_ordering_,sys_code_,creator_,gmt_create_,modifier_,gmt_modified_,is_deleted_,file_key_,business_id_
							,att4_,att5_,att6_,numa2_,numa3_,numa4_,remark_
							from 
							res_file   where id = id_value;

							INSERT into res_design
							(old_id,file_code,file_name,file_original_name,file_type,file_size,file_suffix,
								file_level,file_path,file_desc,file_ordering,sys_code,creator,gmt_create,modifier,gmt_modified,is_deleted,file_key,business_id,
								att4,att5,att6,numa2,numa3,numa4,remark) 
							value 
							(id_value,file_code_,file_name_,file_original_name_,file_type_,file_size_,file_suffix_,
								file_level_,file_path_,file_desc_,file_ordering_,sys_code_,creator_,gmt_create_,modifier_,gmt_modified_,is_deleted_,file_key_,business_id_,
							att4_,att5_,att6_,numa2_,numa3_,numa4_,remark_);
					set i = i-1;
					end while;
			close _Cur; 

 

	end;

