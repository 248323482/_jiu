create
    definer = root@`%` procedure sp_brand_while(IN beginDate varchar(512), IN endDate varchar(512), IN brand_id_ int,
                                                IN brand_name_2 varchar(512))
begin

DECLARE putaway_product_gross_ INT DEFAULT 0;
DECLARE putaway_product_num_ INT DEFAULT 0; 
DECLARE test_product_num_ INT DEFAULT 0; 
DECLARE out_product_num_ INT DEFAULT 0;  

select count(*) into  putaway_product_gross_  from base_product where putaway_state = 1  and brand_id = brand_id_ and is_deleted = 0;
select count(*) into putaway_product_num_ from base_product where putaway_state = 1 and brand_id = brand_id_ and is_deleted = 0 and  putaway_modified between beginDate  and endDate ; 
select count(*) into test_product_num_ from base_product where putaway_state = 2  and brand_id = brand_id_ and is_deleted = 0 and  test_modified between beginDate  and endDate ; 
select count(*) into out_product_num_ from base_product where putaway_state = 0  and brand_id = brand_id_ and is_deleted = 0 and  gmt_create between beginDate  and endDate ;

INSERT into  tmp_table (brand_name_,putaway_product_gross,putaway_product_num,test_product_num,out_product_num) values (brand_name_2,putaway_product_gross_,putaway_product_num_,test_product_num_,out_product_num_) ;
#select     putaway_product_gross_  as '汇总' , putaway_product_num_  as '上架的产品' ,test_product_num_  as '测试中的产品'  , out_product_num_  as '未上架的产品';
 #select  putaway_product_gross as '汇总' ,putaway_product_num as '上架的产品',test_product_num as '测试的产品' ,out_product_num as '未上架的产品' from  tmp_table;
end;

