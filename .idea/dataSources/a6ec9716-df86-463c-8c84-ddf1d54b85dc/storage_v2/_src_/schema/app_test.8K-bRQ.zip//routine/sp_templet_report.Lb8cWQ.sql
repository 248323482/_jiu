create
    definer = root@`%` procedure sp_templet_report(IN beginDate varchar(512), IN endDate varchar(512), IN dateType int)
begin
DECLARE i  INT DEFAULT 0;#循环次数
DECLARE values_ varchar(512);	/**游标的value*/
DECLARE beginString varchar(512);		/**截取时间 年月日 */
DECLARE endString varchar(512);		/**截取时间 年月日 */
DECLARE houseType  INT DEFAULT 0;
DECLARE num_today  INT DEFAULT 0;#当日数量
DECLARE num_weeks  INT DEFAULT 0;#当周数量
DECLARE num_month  INT DEFAULT 0;#当月数量

DECLARE space_total_num_ INT DEFAULT 0;							/**空间总数量*/
DECLARE space_standard_total_num_ INT DEFAULT 0;		/**标准空间总数量*/
DECLARE space_num_ INT DEFAULT 0;										/**新增空间数*/
DECLARE space_standard_num_ INT DEFAULT 0;					/**新增标准空间数*/
DECLARE templet_total_num_ INT DEFAULT 0;						/**样板房总数量*/
DECLARE templet_putaway_toltal_ INT DEFAULT 0;			/**已上架样板房总数量*/
DECLARE templet_putaway_num_ INT DEFAULT 0;					/**新增样板房数（已上架）*/
DECLARE templet_testing_num_ INT DEFAULT 0;					/**新增样板房数（测试中）*/
DECLARE templet_not_putaway_num_ INT DEFAULT 0;			/**新增样板房数（未上架）*/
DECLARE scenes_low_num_ INT DEFAULT 0;							/**新增场景文件数（低模）*/
DECLARE scenes_middle_num_ INT DEFAULT 0;						/**新增场景文件数（中模）*/
DECLARE complete_rate_ varchar(512) DEFAULT '';			/**样板房完成率*/
DECLARE gmt_create_string_ varchar(512) DEFAULT ''; /**创建空间时间*/
DECLARE gmt_statistical_ varchar(512) DEFAULT '';		/**统计时间，系统执行动作时间*/
DECLARE gmt_date_start_ varchar(512) DEFAULT '';        #用作周的时间显示

DECLARE _Cur CURSOR FOR  select value  from sys_dictionary where type='houseType' and is_deleted = 0;/**定义一个游标*/
		/**截取时间 年月日 用作查询 */
select substring_index(beginDate,' ',1) into beginString;
if dateType=2 then#周
		select SUBSTRING_INDEX(beginDate,' ',1) into  gmt_date_start_;
			select substring_index(endDate,' ',1) into endString;
end if;

