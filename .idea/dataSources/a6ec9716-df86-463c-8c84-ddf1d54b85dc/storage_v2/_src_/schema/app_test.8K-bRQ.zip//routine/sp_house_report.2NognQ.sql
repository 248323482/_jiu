create
    definer = root@localhost procedure sp_house_report(IN beginDate varchar(512), IN endDate varchar(512),
                                                       IN dateType int, IN expectSum int)
begin
#DECLARE i INT DEFAULT 0;#循环次数
#DECLARE values_ varchar(512) DEFAULT '';	/**游标的value*/
#DECLARE beginDateStr varchar(512);		/**截取时间 年月日 */
#DECLARE endDateStr varchar(512);		/**截取时间 年月日 */

DECLARE num_today  INT DEFAULT 0;#当日数量
DECLARE num_weeks  INT DEFAULT 0;#当周数量
DECLARE num_month  INT DEFAULT 0;#当月数量

DECLARE expect_living_sum_ int DEFAULT 0;               #预估全国小区总数
DECLARE actual_living_sum_ int DEFAULT 0;               #实际已录入小区总数量
DECLARE expect_living_rate_ varchar(512) DEFAULT '';    #预估小区完成率
DECLARE house_sum_ int DEFAULT 0;               				#户型总数量
DECLARE space_common_sum_ int DEFAULT 0;                #通用空间总数
DECLARE undistributed_space_num_ int DEFAULT 0;         #未进行分配的空间数
DECLARE subspace_sum_ int DEFAULT 0;               			#子空间总数量
DECLARE standard_space_sum_ int DEFAULT 0;              #标准空间总数量
DECLARE exis_sub_stand_num_ int DEFAULT 0;              #存在子空间的标准空间数
DECLARE inexis_sub_stand_num_ int DEFAULT 0;            #不存在子空间的标准空间数
DECLARE posited_house_sum_ int DEFAULT 0;               #已定位户型总数
DECLARE posited_house_rate_ varchar(512) DEFAULT '';    #户型定位完成率
DECLARE add_living_num_ int DEFAULT 0;               		#当日新增小区数
DECLARE add_house_num_ int DEFAULT 0;  									#当日新增户型数
DECLARE add_posited_house_num_ int DEFAULT 0;           #当日新增已定位户型数
DECLARE add_posited_space_num_ int DEFAULT 0;           #当日新增已定位空间数

DECLARE gmt_date_str_ varchar(512) DEFAULT '';          #时间字符类型（日、月用到）
DECLARE gmt_date_start_ varchar(512) DEFAULT '';        #
DECLARE gmt_date_end_ varchar(512) DEFAULT '';          #
DECLARE gmt_create_ varchar(512) DEFAULT '';						#创建时间

#截取时间
if dateType=1 THEN#日
	select SUBSTRING_INDEX(beginDate,' ',1) into  gmt_date_str_;
end if;

