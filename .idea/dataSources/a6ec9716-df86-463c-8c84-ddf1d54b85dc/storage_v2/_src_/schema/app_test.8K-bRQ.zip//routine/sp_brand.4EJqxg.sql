create
    definer = root@`%` procedure sp_brand(IN beginDate varchar(512), IN endDate varchar(512))
begin
DECLARE i  INT DEFAULT 0; 
DECLARE brand_name_ varchar(512);
DECLARE brand_id varchar(512);
DECLARE _Cur CURSOR FOR  select id  from base_brand where is_deleted=0;/**定义一个游标*/
drop table  tmp_table;
CREATE TEMPORARY TABLE tmp_table (
brand_name_   VARCHAR(100),
putaway_product_gross VARCHAR(10),
putaway_product_num VARCHAR(10),
test_product_num VARCHAR(10),
out_product_num VARCHAR(10)
);



/*******开启游标，循环插入******/
select count(*) into i from base_brand where is_deleted=0;

		OPEN _Cur; 
		while i>0  do
			FETCH _Cur INTO brand_id;  
						select brand_name into brand_name_  from base_brand where id =  brand_id;
					CALL  sp_brand_while(beginDate,endDate,brand_id,brand_name_);
				set i = i-1;
				end while;
		close _Cur; 
		/***********关闭游标************/


select * from  tmp_table;
 
end;

